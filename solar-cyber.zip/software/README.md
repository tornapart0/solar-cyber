SPROUT firmware, laptop bridge, and simulator

The XIAO firmware implements the OLED interface, debounced buttons, Wi-Fi bridge requests, paginated answers, and TLV320 headphone playback. The laptop bridge fetches weather, calls a locally running Ollama model, and optionally converts speech to PCM using macOS say and afconvert. It never sends workshop context to a cloud LLM.

Quick start

Weather defaults to Fort Lauderdale city-center coordinates, Fahrenheit and mph. Install Ollama (https://ollama.com/) and Python 3.10 or newer, start Ollama, then run:

ollama pull qwen3:1.7b
python3 start_workshop.py

On macOS, Start Workshop.command and Stop Workshop.command provide launchers. Speech uses macOS say/afconvert; other platforms can run the bridge without --tts. Model weights and runtime are not included.

For physical-device Wi-Fi access, stop the bridge and run python3 start_workshop.py --lan. Use the laptop LAN IP and generated token from .local/sprout-bridge/token.txt in your private Config.h. Never commit that file or token. Workshop context stays with the laptop's local Ollama service; the weather request sends the configured city coordinates to Open-Meteo.

The validation folder contains results from the original prototype development session. They are historical checks, not a claim that services are running on a fresh clone.

Manual or portable setup

1. Install/run Ollama (https://ollama.com/) on the laptop and install a model you choose. The bridge defaults to qwen3:1.7b; override with --model to match an installed model. The original unit tests use mocks; a separate live integration test now also passes with the installed model.
2. In Terminal, change into this software folder. Use Python 3.10 or newer; no third-party Python dependencies are required.
3. Set SPROUT_TOKEN to a private random token of at least 16 characters. For example, generate one with python3 -c 'import secrets; print(secrets.token_hex(24))', then set export SPROUT_TOKEN='your-generated-value'. Use the same token in the device configuration.
4. Write your current task into a local text file such as workshop-context.txt. The bridge reads up to 8192 characters each time ASK is pressed. Updating that file changes the device's workshop context.
5. First test the bridge locally:

python3 bridge/bridge.py --demo --tts

This supplies clearly labelled sample weather and answers plus a quiet diagnostic tone. It does not run an LLM.

For the physical device, run the bridge on your trusted local Wi-Fi network with the installed model name. Fort Lauderdale coordinates are the defaults:

python3 bridge/bridge.py --host 0.0.0.0 --model qwen3:1.7b --context bridge/workshop-context.txt --tts

--host 0.0.0.0 allows LAN access; the default is laptop-only localhost. The bearer token is required on every endpoint. This starter uses HTTP on a trusted LAN, not an internet-facing service. Fort Lauderdale city-center coordinates go to Open-Meteo; workshop text goes only to the laptop's local Ollama API. No automatic location lookup is performed.

Configure and flash the XIAO

Copy firmware/Sprout/Config.example.h to Config.h beside the sketch. Set Wi-Fi name/password, laptop LAN address such as http://192.168.1.100:8765, and bridge token. Keep SPROUT_SIMULATION at 0. The included hardware binary was built with placeholder settings; rebuild with your own configuration before flashing.

Use Arduino IDE with Espressif ESP32 core 3.3.7, board XIAO_ESP32S3, and these libraries:

Library: Tested version
Adafruit SSD1306: 2.5.17
Adafruit GFX Library: 1.12.6
Adafruit BusIO: 1.17.4
Adafruit TLV320 I2S: 1.0.0
ArduinoJson: 7.4.3

Open firmware/Sprout/Sprout.ino, compile, and upload over USB. The software does not automatically flash attached hardware. Equivalent Arduino CLI commands:

arduino-cli core update-index --additional-urls https://espressif.github.io/arduino-esp32/package_esp32_index.json
arduino-cli core install esp32:esp32@3.3.7 --additional-urls https://espressif.github.io/arduino-esp32/package_esp32_index.json
arduino-cli lib install 'Adafruit SSD1306@2.5.17' 'Adafruit GFX Library@1.12.6' 'Adafruit BusIO@1.17.4' 'Adafruit TLV320 I2S@1.0.0' 'ArduinoJson@7.4.3'
arduino-cli compile --fqbn esp32:esp32:XIAO_ESP32S3 firmware/Sprout
arduino-cli upload --fqbn esp32:esp32:XIAO_ESP32S3 --port YOUR_USB_PORT firmware/Sprout

Controls

Tap WEATHER to fetch the forecast.
Tap PREV to cycle workshop prompts. This returns to the prompt selection screen.
Tap ASK on the selection or weather screen to request the selected prompt.
Tap ASK while viewing an answer to advance a page; it wraps after the last page.
Hold ASK for at least 700 ms while viewing an answer to request headphone playback, if audio is available.
Tap any button during playback to stop. Requests run in a worker task so OLED drawing and buttons remain responsive.

The firmware uses GPIO 1/2/4 for buttons, 5/6 for OLED/DAC I2C, 7/8/9 for I2S, and 44 for DAC reset. The OLED is 128×32 at 0x3C; the DAC is 0x18. The DAC is configured for stereo 48 kHz, 16-bit I2S, no MCLK, muted at initialization, attenuated headphone output, and speaker amplifier disabled. Playback audio is raw stereo signed 16-bit little-endian PCM. This revision has no microphone or keyboard.

Simulator project

simulator/diagram.json wires an ESP32-S3 DevKit surrogate to an SSD1306 and three buttons using the same GPIO nets as the carrier. Wokwi provides a 128×64 OLED; the interface uses only the upper 128×32 pixels. It is a functional digital circuit simulation, not an import of KiCad copper or a physical XIAO/regulator/battery model.

The same firmware source and shared Core.h are used with SPROUT_SIMULATION=1. That mode substitutes deterministic weather/answer responses, skips Wi-Fi and codec configuration, and logs headphone playback requests without modeling the DAC. This makes UI checks reproducible and does not claim live weather, live LLM inference, or actual headphone output in Wokwi.

To reproduce in the browser:

1. Open a new ESP32-S3 Wokwi project (https://wokwi.com/projects/new/esp32-s3).
2. Replace sketch.ino, diagram.json, and libraries.txt with the files in simulator/. Start the simulation. The generated sketch combines the actual firmware and Core.h for a single-file browser project.
3. Alternatively, load simulator/bin/Sprout.ino.merged.bin using F1 → Upload Firmware and Start Simulation. This merged file includes bootloader, partitions, and the compiled simulator application. The uploaded binary applies to that run; regular Start builds the editor source.

The wokwi.toml also supports Wokwi in VS Code or CLI with the compiled simulator binary. CLI/VS Code may require your own Wokwi account/license or token. The browser simulation was run without creating an account.

Automated checks

simulator/test_core.cpp: 19 checks run against the exact Core.h compiled into the ESP32 firmware: bounce, busy behavior, button dispatch, pagination, hold/release behavior, playback cancellation, failure recovery, text bounds, and millis rollover.
simulator/test_bridge.py: HTTP integration tests using a real localhost bridge server, covering authorization, presets, weather fixtures, audio format, expiry, routes, missing configuration, and the mocked local model contract.
validation/board-pin-check.txt: checked the actual KiCad U1 pad nets against firmware GPIO constants and the standard XIAO pinout.
validation/build-hardware.txt and build-simulation.txt: real successful ESP32 cross-compilation reports.
validation/tts-test.txt: actual macOS speech conversion check.

Run the host checks from this folder:

c++ -std=c++17 simulator/test_core.cpp -o /tmp/sprout-core-test
/tmp/sprout-core-test
python3 simulator/test_bridge.py

The binary upload and browser source project both exercise the ESP32-S3 emulator. The DAC/I2S electrical output, battery switch/charger, current draw, RF performance, shorts, mechanical fit, and real headphone volume remain bench tests. KiCad DRC/ERC reports are in the parent project's validation folder.

API

All endpoints require Authorization: Bearer <token>.

Endpoint: Behavior
GET /v1/health: Bridge status and demo flag
GET /v1/weather: JSON {text}
POST /v1/ask: JSON request {preset: 0..2}; response {text, audio_id?}
GET /v1/audio/hex-id: Raw 48 kHz stereo PCM, bounded to 60 seconds; cache expires after 10 minutes

Errors return appropriate HTTP status codes and do not leave the device permanently busy. A request may take up to 60 seconds before the device's network timeout; shorten the answer or choose a faster installed model if needed.

References: Espressif I2S API (https://docs.espressif.com/projects/arduino-esp32/en/latest/api/i2s.html), Adafruit codec library (https://github.com/adafruit/Adafruit_TLV320_I2S), Wokwi ESP32 support (https://docs.wokwi.com/guides/esp32), OLED model (https://docs.wokwi.com/parts/board-ssd1306), Ollama generate API (https://docs.ollama.com/api/generate), Open-Meteo forecast API (https://open-meteo.com/en/docs).
