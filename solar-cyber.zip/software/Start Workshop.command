#!/bin/zsh
cd "${0:A:h}"
SPROUT_PYTHON='python3'
if [[ ! -x "$SPROUT_PYTHON" ]]; then
  SPROUT_PYTHON=$(command -v python3)
fi
"$SPROUT_PYTHON" "$PWD/start_workshop.py" "$@"
