#!/usr/bin/env python3
"""SPROUT LAN bridge. Python 3.10+, standard library only."""
import argparse, hmac, json, math, os, re, struct, subprocess, tempfile, threading, time, uuid, wave
from collections import OrderedDict
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import URLError

PROMPTS = ['Suggest the next repair step.', 'Explain the circuit described in the context.', 'Give a short workshop checklist for this task.']
SYSTEM = 'You are a concise workshop assistant. Use the supplied context. If details are missing, say what must be checked. Do not invent component ratings. Give at most 100 words. Plain text only.'
MAX_AUDIO = 48000 * 4 * 60

def get_json(url, body=None, timeout=45):
    data = None if body is None else json.dumps(body).encode()
    request = Request(url, data=data, headers={'Content-Type': 'application/json'})
    with urlopen(request, timeout=timeout) as r:
        raw = r.read(65537)
        if len(raw) > 65536: raise ValueError('Upstream response too large')
        return json.loads(raw)

class Bridge:
    def __init__(self, *, demo=False, model='qwen3:1.7b', ollama='http://127.0.0.1:11434', context=None, lat=None, lon=None, tts=False):
        self.demo,self.model,self.ollama,self.context,self.lat,self.lon,self.tts = demo,model,ollama,context,lat,lon,tts
        self.cache=OrderedDict(); self.lock=threading.Lock(); self.ask_lock=threading.Lock()
    def weather(self):
        if self.demo: return {'text': '21 C / light clouds. Wind 8 km/h. DEMO weather, not live.'}
        if self.lat is None or self.lon is None: raise ValueError('Set --lat and --lon for weather')
        data=get_json(f'https://api.open-meteo.com/v1/forecast?latitude={self.lat}&longitude={self.lon}&current=temperature_2m,weather_code,wind_speed_10m&temperature_unit=fahrenheit&wind_speed_unit=mph&timezone=auto',timeout=10)['current']
        code=int(data['weather_code']); desc=('clear' if code==0 else 'cloudy' if code in (1,2,3) else 'fog' if code in (45,48) else 'snow' if code in (71,73,75,77,85,86) else 'thunderstorm' if code in (95,96,99) else 'rain / showers')
        place='Ft Lauderdale: ' if abs(self.lat-26.12231)<0.01 and abs(self.lon+80.14338)<0.01 else ''
        return {'text': f"{place}{data['temperature_2m']} F / {desc}. Wind {data['wind_speed_10m']} mph.",'updated':data['time']}
    def ask(self,preset):
        if type(preset) is not int or not 0<=preset<len(PROMPTS): raise ValueError('preset must be 0, 1, or 2')
        if not self.ask_lock.acquire(blocking=False): raise BlockingIOError('An answer is already being generated')
        try:
            if self.demo: text=f'DEMO prompt {preset}: Disconnect power, inspect connectors, document the symptom, and test one change at a time. This is a fixture, not an LLM answer.'
            else:
                context='No task context supplied.'
                if self.context:
                    with open(self.context,'r',encoding='utf8') as f: context=f.read(8192)
                result=get_json(self.ollama+'/api/generate',{'model':self.model,'system':SYSTEM,'prompt':f'Workshop context:\n{context}\n\nQuestion: {PROMPTS[preset]}','stream':False,'think':False,'options':{'num_predict':180,'num_ctx':4096,'temperature':0.3}})
                text=result.get('response','')
                if not isinstance(text,str) or not text.strip(): raise ValueError('Local model returned no answer')
                text=re.sub(r'<think>.*?</think>','',text,flags=re.S).strip()
            text=' '.join(text.split())[:1024]
            answer={'text':text}
            if self.tts:
                try: pcm=self.speech(text)
                except (OSError, subprocess.SubprocessError, ValueError):
                    pcm=b'';answer['audio_error']='Speech unavailable; text response retained'
                if pcm:
                    ident=uuid.uuid4().hex
                    with self.lock:
                        self.prune();self.cache[ident]=(time.monotonic(),pcm)
                        while len(self.cache)>4:self.cache.popitem(last=False)
                    answer['audio_id']=ident
            return answer
        finally:self.ask_lock.release()
    def prune(self):
        now=time.monotonic()
        for key,(stamp,_) in list(self.cache.items()):
            if now-stamp>600:self.cache.pop(key)
    def audio(self,ident):
        if not re.fullmatch('[a-f0-9]{32}',ident):raise KeyError(ident)
        with self.lock:self.prune();return self.cache[ident][1]
    def speech(self,text):
        if self.demo:
            # Quiet diagnostic tone, not synthesized speech. Stereo signed 16-bit LE.
            return b''.join(struct.pack('<hh',s,s) for i in range(24000) for s in [int(800*math.sin(2*math.pi*440*i/48000))])
        if not Path('/usr/bin/say').exists():return b''
        with tempfile.TemporaryDirectory(prefix='sprout-tts-') as d:
            aiff=Path(d)/'speech.aiff';wav=Path(d)/'speech.wav';textfile=Path(d)/'speech.txt'
            textfile.write_text(text,encoding='utf8')
            subprocess.run(['/usr/bin/say','-o',str(aiff),'-f',str(textfile)],check=True,timeout=20,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            subprocess.run(['/usr/bin/afconvert','-f','WAVE','-d','LEI16@48000','-c','2',str(aiff),str(wav)],check=True,timeout=10,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            with wave.open(str(wav),'rb') as f:
                if (f.getframerate(),f.getnchannels(),f.getsampwidth())!=(48000,2,2):raise ValueError('Unsupported TTS audio format')
                raw=f.readframes(48000*60)
            samples=struct.unpack('<'+'h'*(len(raw)//2),raw)
            # Attenuate and hard bound digital signal. Codec applies additional attenuation.
            return struct.pack('<'+'h'*len(samples),*(max(-4096,min(4096,int(s/4))) for s in samples))

def make_server(bridge,token,host='127.0.0.1',port=8765):
    if not token or len(token)<16:raise ValueError('SPROUT_TOKEN must contain at least 16 characters')
    class Handler(BaseHTTPRequestHandler):
        protocol_version='HTTP/1.1'
        def log_message(self,*args):pass  # Never log authorization headers or question/context.
        def send_body(self,status,data,ctype='application/json'):
            if not isinstance(data,bytes):data=json.dumps(data).encode()
            self.send_response(status);self.send_header('Content-Type',ctype);self.send_header('Content-Length',str(len(data)));self.send_header('Connection','close');self.end_headers()
            try:self.wfile.write(data)
            except (BrokenPipeError,ConnectionResetError):pass
            self.close_connection=True
        def authorized(self):
            if not hmac.compare_digest(self.headers.get('Authorization',''),f'Bearer {token}'):
                self.send_body(401,{'error':'Unauthorized'});return False
            return True
        def do_GET(self):
            if not self.authorized():return
            try:
                if self.path=='/v1/health':self.send_body(200,{'ok':True,'demo':bridge.demo,'model':bridge.model})
                elif self.path=='/v1/weather':self.send_body(200,bridge.weather())
                elif self.path.startswith('/v1/audio/'):self.send_body(200,bridge.audio(self.path.removeprefix('/v1/audio/')),'application/octet-stream')
                else:self.send_body(404,{'error':'Not found'})
            except KeyError:self.send_body(404,{'error':'Audio expired or not found'})
            except Exception:self.send_body(502,{'error':'Weather or audio unavailable; check bridge configuration'})
        def do_POST(self):
            if not self.authorized():return
            if self.path!='/v1/ask':self.send_body(404,{'error':'Not found'});return
            try:
                length=int(self.headers.get('Content-Length','0'))
                if not 0<length<=4096:raise ValueError('Invalid request size')
                self.connection.settimeout(5)
                body=json.loads(self.rfile.read(length));preset=body.get('preset')
                if type(preset) is not int or not 0<=preset<3:raise ValueError('Invalid preset')
            except (ValueError,AttributeError):
                self.send_body(400,{'error':'Invalid request; preset must be 0, 1, or 2'});return
            except (TimeoutError, OSError):
                self.send_body(400,{'error':'Request body timeout'});return
            try:
                self.send_body(200,bridge.ask(preset))
            except BlockingIOError:self.send_body(409,{'error':'Busy'})
            except Exception:self.send_body(502,{'error':'Local model or speech unavailable; check Ollama and model name'})
    return ThreadingHTTPServer((host,port),Handler)

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--host',default='127.0.0.1');p.add_argument('--port',type=int,default=8765);p.add_argument('--demo',action='store_true');p.add_argument('--tts',action='store_true');p.add_argument('--model',default='qwen3:1.7b');p.add_argument('--context',type=Path);p.add_argument('--lat',type=float,default=26.12231);p.add_argument('--lon',type=float,default=-80.14338)
    a=p.parse_args()
    if (a.lat is not None and not -90<=a.lat<=90) or (a.lon is not None and not -180<=a.lon<=180):p.error('Invalid coordinates')
    b=Bridge(demo=a.demo,tts=a.tts,model=a.model,context=a.context,lat=a.lat,lon=a.lon)
    try:server=make_server(b,os.getenv('SPROUT_TOKEN',''),a.host,a.port)
    except ValueError as e:p.error(str(e))
    print(f'SPROUT bridge listening on {a.host}:{server.server_port}; demo={a.demo}. Ctrl-C to stop.',flush=True)
    try:server.serve_forever()
    except KeyboardInterrupt:pass
    finally:server.server_close()
if __name__=='__main__':main()
