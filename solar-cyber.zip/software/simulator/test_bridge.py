import importlib.util,json,threading,unittest,urllib.request,urllib.error,struct,time
from pathlib import Path
p=Path(__file__).resolve().parents[1]/'bridge/bridge.py'
spec=importlib.util.spec_from_file_location('bridge',p);bridge=importlib.util.module_from_spec(spec);spec.loader.exec_module(bridge)
TOKEN='test-token-for-local-simulator'
class BridgeTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.b=bridge.Bridge(demo=True,tts=True);cls.s=bridge.make_server(cls.b,TOKEN,port=0);cls.t=threading.Thread(target=cls.s.serve_forever,daemon=True);cls.t.start();cls.url=f'http://127.0.0.1:{cls.s.server_port}'
 @classmethod
 def tearDownClass(cls):cls.s.shutdown();cls.s.server_close();cls.t.join()
 def call(self,path,body=None,auth=True):
  headers={'Content-Type':'application/json'}
  if auth:headers['Authorization']='Bearer '+TOKEN
  req=urllib.request.Request(self.url+path,data=None if body is None else json.dumps(body).encode(),headers=headers)
  with urllib.request.urlopen(req,timeout=5) as r:return r.status,r.headers,r.read()
 def test_health(self):self.assertTrue(json.loads(self.call('/v1/health')[2])['demo'])
 def test_unauthorized(self):
  with self.assertRaises(urllib.error.HTTPError) as e:self.call('/v1/weather',auth=False)
  self.assertEqual(e.exception.code,401)
 def test_weather(self):self.assertIn('DEMO',json.loads(self.call('/v1/weather')[2])['text'])
 def test_all_presets(self):
  for n in range(3):self.assertIn(f'prompt {n}',json.loads(self.call('/v1/ask',{'preset':n})[2])['text'])
 def test_invalid_preset(self):
  for n in [-1,3,True,'0',None]:
   with self.assertRaises(urllib.error.HTTPError) as e:self.call('/v1/ask',{'preset':n})
   self.assertEqual(e.exception.code,400)
 def test_audio_format(self):
  answer=json.loads(self.call('/v1/ask',{'preset':0})[2]);status,h,pcm=self.call('/v1/audio/'+answer['audio_id']);self.assertEqual(h['Content-Type'],'application/octet-stream');self.assertEqual(len(pcm),48000*4//2)
  samples=struct.unpack('<'+'h'*(len(pcm)//2),pcm);self.assertLessEqual(max(map(abs,samples)),800);self.assertEqual(samples[::2],samples[1::2])
  (Path(__file__).parents[1]/'validation/demo-audio.pcm').write_bytes(pcm)
 def test_audio_expiry(self):
  self.b.cache['b'*32]=(time.monotonic()-601,b'0000')
  with self.assertRaises(urllib.error.HTTPError) as e:self.call('/v1/audio/'+'b'*32)
  self.assertEqual(e.exception.code,404)
 def test_unknown_route(self):
  with self.assertRaises(urllib.error.HTTPError) as e:self.call('/missing')
  self.assertEqual(e.exception.code,404)
 def test_missing_weather_config(self):
  with self.assertRaises(ValueError):bridge.Bridge().weather()
 def test_real_ollama_contract(self):
  old=bridge.get_json;calls=[]
  def fake(url,body=None,timeout=45):calls.append((url,body));return {'response':'<think>reasoning</think>Check connector polarity.'}
  bridge.get_json=fake
  try:
   real=bridge.Bridge();answer=real.ask(1);self.assertEqual(answer['text'],'Check connector polarity.');self.assertEqual(calls[0][0],'http://127.0.0.1:11434/api/generate');self.assertFalse(calls[0][1]['stream']);self.assertEqual(calls[0][1]['options']['num_predict'],180)
  finally:bridge.get_json=old
 def test_busy_conflict(self):
  self.b.ask_lock.acquire()
  try:
   with self.assertRaises(urllib.error.HTTPError) as e:self.call('/v1/ask',{'preset':0})
   self.assertEqual(e.exception.code,409)
  finally:self.b.ask_lock.release()
 def test_optional_speech_failure_retains_text(self):
  b=bridge.Bridge(demo=True,tts=True)
  def fail(_):raise OSError('speech missing')
  b.speech=fail;answer=b.ask(0);self.assertIn('text',answer);self.assertIn('audio_error',answer);self.assertNotIn('audio_id',answer)
 def test_upstream_failure_status(self):
  old=self.b.ask
  def fail(_):raise ValueError('model returned empty answer')
  self.b.ask=fail
  try:
   with self.assertRaises(urllib.error.HTTPError) as e:self.call('/v1/ask',{'preset':0})
   self.assertEqual(e.exception.code,502)
  finally:self.b.ask=old
if __name__=='__main__':unittest.main(verbosity=2)
