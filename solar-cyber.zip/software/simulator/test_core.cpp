#include "../firmware/Sprout/Core.h"
#include <assert.h>
#include <iostream>
#include <string>
using namespace sprout;
int checks=0;void check(bool b,const char* name){if(!b){std::cerr<<"FAIL "<<name<<"\n";exit(1);}++checks;std::cout<<"PASS "<<name<<"\n";}
Action press(App& a,int pin,uint32_t t,bool hold=false){bool v[3]={false,false,false};v[pin]=true;a.update(v[0],v[1],v[2],t);a.update(v[0],v[1],v[2],t+31);Action result=Action::None;if(hold)result=a.update(v[0],v[1],v[2],t+750);a.update(false,false,false,t+(hold?800:100));Action release=a.update(false,false,false,t+(hold?831:131));return hold?result:release;}
int main(){
 App a;check(a.pages()==1,"boot screen");
 a.update(true,false,false,0);a.update(false,false,false,4);a.update(false,false,false,40);check(!a.busy,"button bounce ignored");
 check(press(a,0,100)==Action::Weather&&a.busy,"WEATHER dispatch and busy");
 check(press(a,2,1100)==Action::None,"busy suppresses duplicate request");
 a.complete("WEATHER","21 C / clouds");check(!a.busy&&!a.answer,"weather response displayed");
 press(a,1,2100);check(a.preset==1,"PREV selects next preset");
 check(press(a,2,3100)==Action::Ask,"ASK dispatch");
 a.complete("WORKSHOP",std::string(150,'x').c_str(),true,"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");check(a.pages()==3,"long answer paginated");
 press(a,2,4100);check(a.page==1,"ASK advances answer page");
 char lines[3][22];a.lines(lines);check(strlen(lines[0])==21&&strlen(lines[2])==21,"OLED bounded 21-column rows");
 check(press(a,2,5100,true)==Action::Audio&&a.playing,"hold ASK starts audio once");
 check(press(a,0,6100)==Action::StopAudio,"button stops playback");a.playing=false;
 a.complete("CONNECTION","Bridge error 401");check(!a.busy&&!a.answer,"network failure recovery");
 a.set("TEXT","temperature \xc2\xb0\nOK");check(std::string(a.text)=="temperature ? OK","UTF-8 and newline normalized");
 a.set("BOUND",std::string(4096,'z').c_str());check(strlen(a.text)==1024&&a.pages()==17,"oversized answer bounded");
 Button b;b.update(true,0xfffffff0U);b.update(true,0x10U);check(b.stable,"debounce across millis wrap");check(b.update(true,0x300U)==2,"hold across millis wrap");
 App noAudio;noAudio.complete("ANSWER","No audio",true);check(press(noAudio,2,100,true)==Action::None,"missing audio does not dispatch");
 check(WEATHER_PIN==1&&PREV_PIN==2&&ASK_PIN==4&&SDA_PIN==5&&SCL_PIN==6&&BCLK_PIN==7&&WSEL_PIN==8&&DATA_PIN==9&&RESET_PIN==44,"carrier GPIO mapping");
 std::cout<<checks<<" checks passed. Same Core.h is compiled into ESP32 firmware.\n";
}
