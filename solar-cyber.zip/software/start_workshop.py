#!/usr/bin/env python3
"""Start the laptop's local model service and Fort Lauderdale workshop bridge."""
import argparse,importlib.util,json,os,shutil,shlex,signal,subprocess,time,urllib.request
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
STATE=ROOT/'.local/sprout-bridge'
OLLAMA_STATE=ROOT/'.local/ollama'

def get(url):
    with urllib.request.urlopen(url,timeout=2) as r:return json.load(r)

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--lan',action='store_true',help='Allow the physical keychain to connect over trusted local Wi-Fi');parser.add_argument('--port',type=int,default=8765);parser.add_argument('--stop',action='store_true',help='Stop this project bridge')
    a=parser.parse_args();STATE.mkdir(parents=True,exist_ok=True)
    pidfile=STATE/'bridge.pid'
    if a.stop:
        if not pidfile.exists():print('Project bridge is not running.');return
        try:
            pid=int(pidfile.read_text());command=subprocess.check_output(['/bin/ps','-p',str(pid),'-o','command='],text=True).strip()
            if not any(arg.endswith('start_workshop.py') and Path(arg).resolve()==Path(__file__).resolve() for arg in shlex.split(command)):parser.error('PID no longer belongs to this bridge; no process stopped.')
            os.kill(pid,signal.SIGINT);print('Stopped the project bridge. The local Ollama service remains available.')
        except (ValueError,ProcessLookupError,subprocess.CalledProcessError):print('Project bridge is not running.')
        return
    try:get('http://127.0.0.1:11434/api/tags')
    except OSError:
        candidates=[os.environ.get('SPROUT_OLLAMA_BIN',''),str(OLLAMA_STATE/'runtime/ollama'),shutil.which('ollama') or '', '/Applications/Ollama.app/Contents/Resources/ollama']
        executable=next((p for p in candidates if p and Path(p).is_file()),None)
        if not executable:parser.error('Ollama runtime not found. Install Ollama or set SPROUT_OLLAMA_BIN.')
        env=os.environ.copy();env.update(OLLAMA_HOST='127.0.0.1:11434',OLLAMA_NO_CLOUD='1',OLLAMA_CONTEXT_LENGTH='4096')
        with (STATE/'ollama.log').open('a') as log:subprocess.Popen([executable,'serve'],env=env,stdout=log,stderr=log,start_new_session=True)
        for _ in range(100):
            try:get('http://127.0.0.1:11434/api/tags');break
            except OSError:time.sleep(0.2)
        else:parser.error('Ollama did not start; see .local/sprout-bridge/ollama.log')
    tags=get('http://127.0.0.1:11434/api/tags')
    if not any(m['name']=='qwen3:1.7b' for m in tags.get('models',[])):parser.error('Download the model first: ollama pull qwen3:1.7b (using the project runtime if needed).')
    token=os.environ.get('SPROUT_TOKEN','');tokenfile=STATE/'token.txt'
    if not token:
        if tokenfile.exists():token=tokenfile.read_text().strip()
        else:
            import secrets
            token=secrets.token_hex(24);tokenfile.write_text(token+'\n');tokenfile.chmod(0o600)
    try:
        request=urllib.request.Request(f'http://127.0.0.1:{a.port}/v1/health',headers={'Authorization':'Bearer '+token})
        with urllib.request.urlopen(request,timeout=2) as response:healthy=json.load(response)
        if healthy.get('ok'):
            print(f'Project bridge already running on port {a.port}. Stop it before changing LAN mode.');return
    except OSError:pass
    spec=importlib.util.spec_from_file_location('sprout_bridge',HERE/'bridge/bridge.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    bridge=module.Bridge(model='qwen3:1.7b',context=HERE/'bridge/workshop-context.txt',lat=26.12231,lon=-80.14338,tts=True)
    host='0.0.0.0' if a.lan else '127.0.0.1'
    try:server=module.make_server(bridge,token,host,a.port)
    except OSError as e:parser.error(f'Could not start bridge: {e}')
    pidfile.write_text(str(os.getpid()));pidfile.chmod(0o600)
    print(f'SPROUT ready: Fort Lauderdale weather + local qwen3:1.7b + speech. Listening on {host}:{a.port}.',flush=True)
    print('For the physical device, copy the private token from .local/sprout-bridge/token.txt into Config.h. Use --lan to allow local Wi-Fi connections.',flush=True)
    try:server.serve_forever()
    except KeyboardInterrupt:pass
    finally:
        server.server_close()
        if pidfile.exists() and pidfile.read_text()==str(os.getpid()):pidfile.unlink()
if __name__=='__main__':main()
