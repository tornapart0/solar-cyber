# SPROUT software validation — 2026-10-10

**Result:** hardware firmware compiles; shared application logic and bridge checks pass; compiled simulator firmware and the browser source project both ran in Wokwi.

| Check | Observed result |
|---|---|
| ESP32 core 3.3.7 / XIAO ESP32-S3 hardware build | PASS: 990752 bytes flash, 48244 bytes static RAM |
| ESP32-S3 simulator build, SPROUT_SIMULATION=1 | PASS: 920841 bytes flash, 46788 bytes static RAM |
| Shared C++ application logic | 19 checks passed |
| Python bridge / real localhost HTTP server | 13 tests passed |
| Actual KiCad U1 pad nets vs firmware GPIO mapping | 9 signal mappings passed |
| macOS say / afconvert | PASS: 48 kHz, stereo, signed 16-bit little-endian PCM |
| Live local-model/weather/speech bridge | PASS: real qwen3:1.7b answer, Fort Lauderdale forecast, authenticated PCM retrieval |
| Wokwi compiled binary boot | SPROUT_READY observed |
| Wokwi browser source compilation and boot | SPROUT_READY observed |
| Wokwi WEATHER button | Forecast fixture displayed, explicitly marked DEMO |
| Wokwi PREV button | Selected Explain this circuit preset |
| Wokwi ASK button | Answer fixture displayed, pages 1/3 and 2/3 observed |
| Wokwi hold ASK | ACTION 3 and SIM_AUDIO_REQUEST observed |

`wokwi-observed.txt` contains the actual browser accessibility output with serial messages. `wokwi-test.png` shows the running circuit and output. Both binary and source simulations used the same Core.h and firmware logic; simulator fixtures replaced the laptop and unsupported codec.

Not verified by this run: physical PCB copper behavior, battery/charger operation, analog headphone output, I2S waveform correctness at the DAC, assembly fit, current consumption, or the accuracy of local-model advice. Ollama 0.40.2 and qwen3:1.7b are now installed locally. The isolated unit tests still mock the model API; a separate real inference test passed. Real Fort Lauderdale weather, a local qwen3:1.7b model response, and macOS speech/audio retrieval now pass the separate live integration test; see live-integration.json. City-center coordinates and Fahrenheit/mph are configured.

Wokwi used an ESP32-S3 DevKit surrogate with matching GPIO wiring and a 128×64 OLED showing the upper 128×32 interface. It did not load KiCad copper geometry. Existing KiCad DRC/ERC/parity reports are separate PCB checks, not firmware simulation.

The hardware build has placeholder Wi-Fi and bridge settings and was not flashed onto a device. Configure and rebuild before hardware use.
